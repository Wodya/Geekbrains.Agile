<table class="table table-bordered">
    <thead>
    <tr>
        <th>id</th>
        <th>Наименование</th>
        <th>Инфо</th>
        <th>Путь</th>
        <th>Теги</th>
    </tr>
    </thead>
    <tbody>
<?php $__empty_1 = true; $__currentLoopData = $PlantList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($plant->id); ?></td>
        <td><?php echo e($plant->name); ?></td>
        <td><?php echo e($plant->shortInfo); ?></td>
        <td><?php echo e($plant->photoSmallPath); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h2>Растений нет</h2>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /home/vagrant/code/resources/views/test/index.blade.php ENDPATH**/ ?>